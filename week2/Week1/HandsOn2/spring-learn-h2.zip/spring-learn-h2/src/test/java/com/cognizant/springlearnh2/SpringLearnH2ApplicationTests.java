package com.cognizant.springlearnh2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringLearnH2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
