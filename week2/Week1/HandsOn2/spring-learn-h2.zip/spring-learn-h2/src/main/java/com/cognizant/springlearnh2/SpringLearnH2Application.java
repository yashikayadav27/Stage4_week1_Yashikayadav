package com.cognizant.springlearnh2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringLearnH2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringLearnH2Application.class, args);
	}

}
