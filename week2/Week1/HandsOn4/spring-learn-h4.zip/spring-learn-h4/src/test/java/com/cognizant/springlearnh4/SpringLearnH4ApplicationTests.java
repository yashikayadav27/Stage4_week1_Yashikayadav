package com.cognizant.springlearnh4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringLearnH4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
