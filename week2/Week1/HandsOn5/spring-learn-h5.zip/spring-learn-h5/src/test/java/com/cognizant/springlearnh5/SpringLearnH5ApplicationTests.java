package com.cognizant.springlearnh5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringLearnH5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
